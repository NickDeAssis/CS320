import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		Scanner scnr = new Scanner(System.in);
		ContactService contactservicer = new ContactService();
		Contact contact1 = new Contact();
		
		contactservicer.setContactFirstName(contact1);
		
		contact1.printContactInfo();
	}

}

