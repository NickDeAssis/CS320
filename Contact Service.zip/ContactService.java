import java.util.Scanner;

public class ContactService {
	 Scanner scnr = new Scanner(System.in);
	
	public void setContactFirstName(Contact contact) {
		System.out.println("Please provide a name for the contact");
		contact.setContactFirstName(scnr.nextLine());
		contact.contactCheck();
	}
}
