
public class Contact {

	private String contactID;
	public String contactFirstName;
	public String contactLastName;
	public String contactPhoneNumber;
	public String contactAddress;
	
	// Default constructor
	public Contact() {
		contactID = "0";
		contactFirstName = "0";
		contactLastName = "0";
		contactPhoneNumber = "0000000000";
		contactAddress = "0";
	}
	
	public void contactCheck() {
		if(contactID == null || contactID.length()>10) {
			throw new IllegalArgumentException("Invalid Contact ID");
		}
		if(contactFirstName == null || contactFirstName.length()>10) {
			throw new IllegalArgumentException("Invalid Contact First Name");
		}
		if(contactLastName == null || contactLastName.length()>10) {
			throw new IllegalArgumentException("Invalid Contact Last Name");
		}
		if(contactPhoneNumber == null || contactPhoneNumber.length()>10 || contactPhoneNumber.length()<10 ) {
			throw new IllegalArgumentException("Invalid Contact Phone Number");
		}
		if(contactAddress == null || contactAddress.length()>30) {
			throw new IllegalArgumentException("Invalid Contact Name");
		}
	}
	
	public void setContactFirstName(String contactFirstName) {
		this.contactFirstName = contactFirstName;
		
	}
	
	public void printContactInfo() {
		System.out.println("Contact ID: " + contactID);
		System.out.println("Contact First Name: " + contactFirstName);
		System.out.println("Contact Last Name: " + contactLastName);
		System.out.println("Contact Phone Number: " + contactPhoneNumber);
		System.out.println("Contact Address: " + contactAddress);
	}


	
}
